﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Source
{
    public class Tetromino
    {
        readonly string[] orientations;
        readonly int currentOrientation;

        public Tetromino(params string[] o) : this(0,o) { }

        private Tetromino(int current, params string[] orientations)
        {
            this.currentOrientation = (current + orientations.Length) % orientations.Length;
            this.orientations = orientations;
        }

        public static readonly Tetromino T_SHAPE 
            = new Tetromino(
                "....\n" +
                "TTT.\n" +
                ".T..\n"
            ,
                ".T..\n" +
                "TT..\n" +
                ".T..\n"
            ,
                "....\n" +
                ".T..\n" +
                "TTT.\n"
            ,
                ".T..\n" +
                ".TT.\n" +
                ".T..\n"
            );

        public override string ToString()
        {
            return orientations[currentOrientation];
        }

        public Tetromino RotateRight()
        {
            return new Tetromino(this.currentOrientation + 1, this.orientations);
        }

        public Tetromino RotateLeft()
        {
            return new Tetromino(this.currentOrientation - 1, this.orientations);
        }
    }
}
