﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Source
{
    public class Board
    {
        static readonly char EMPTY = '.';
        readonly int Columns, Rows;

        char[,] board;
        Block fallingBlock;

        public Board(int rows, int columns)
        {
            this.Rows = rows;
            this.Columns = columns;
            board = new char[rows, columns];

            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < columns; col++)
                {
                    board[row, col] = EMPTY;
                }
            }
        }

        public override String ToString()
        {
            String s = "";
            for (int row = 0; row < Rows; row++)
            {
                for (int col = 0; col < Columns; col++)
                {
                    if (IsFallingBlock())
                    {
                        s += fallingBlock.Trouver(row, col) ? 
                            fallingBlock.Shape : board[row, col];
                    }
                    else s += board[row, col];
                }
                s += "\n";
            }
            return s;
        }

        void CheckIsFalling()
        {
            if (IsFallingBlock())
                throw new ArgumentException("Another block is already falling!");
        }

        public bool IsFallingBlock()
        {
            return fallingBlock != null;
        }

        public void Drop(Block block)
        {
            CheckIsFalling();
            fallingBlock = block.MoveTo(0,Columns/2);
        }

        public void Drop(Tetromino tetromino)
        {
            CheckIsFalling();

        }

        public void Tick()
        {
            Block test = fallingBlock.MoveDown();
            if (ConflictWithBoard(test)) StopFallingBlock();            
            else fallingBlock = test;            
        }

        private void StopFallingBlock()
        {
            CopyToBoard(fallingBlock);
            fallingBlock = null;
        }

        private void CopyToBoard(Block b)
        {
            board[b.Row, b.Col] = b.Shape;
        }

        private bool ConflictWithBoard(Block block)
        {
            return OutsideBoard(block) || HitsAnotherBlock(block);
        }

        private bool HitsAnotherBlock(Block block)
        {
            return board[block.Row, block.Col] != EMPTY;
        }

        private bool OutsideBoard(Block block)
        {
            return block.Row >= Rows;
        }
    }
}
